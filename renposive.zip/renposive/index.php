<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="STYLE/Style.css">
    <title>Document</title>
</head>
<body>
    <?php include("view/menu.php"); ?>
    <div class="container">
        <?php //include("view/header.php"); ?>
        <div class="content">
            <div class="cards">
                <div class="card">
                    <div class="box">
                        <h1>2194</h1>
                        <h3>students</h3>
                    </div>
                    <div class="icono-case">
                        <img src="image/students.png" alt="">
                    </div>
                </div> 
                <div class="card">
                    <div class="box">
                        <h1>53</h1>
                        <h3>teacher</h3>
                    </div>
                    <div class="icono-case">
                        <img src="image/teachers.png" alt="">
                    </div>
                </div>
                <div class="card">
                    <div class="box">
                        <h1>5</h1>
                        <h3>school</h3>
                    </div>
                    <div class="icono-case">
                        <img src="image/schools.png" alt="">
                    </div>
                </div>
                <div class="card">
                    <div class="box">
                        <h1>350000</h1>
                        <h3>income</h3>
                    </div>
                    <div class="icono-case">
                        <img src="image/income.png" alt="">
                    </div>
                </div>
            </div>
            <div class="content-2">
                <div class="recent-payments">
                    <div class="title">
                        <h2>Recent payments</h2>
                        <a href="#" class="btn">view all</a>
                    </div>
                    <table>
                        <tr>
                            <th>name</th>
                            <th>school</th>
                            <th>amount</th>
                            <th>option</th>
                        </tr>
                        <tr>
                            <td>jhon doe</td>
                            <td>st james collge</td>
                            <td>$120</td>
                            <td><a href="#"class="btn">view</a></td>
                        </tr>
                        <tr>
                            <th>name</th>
                            <th>school</th>
                            <th>amount</th>
                            <th>option</th>
                        </tr>
                        <tr>
                            <td>jhon doe</td>
                            <td>st james collge</td>
                            <td>$120</td>
                            <td><a href="#"class="btn">view</a></td>
                        </tr>
                        <tr>
                            <th>name</th>
                            <th>school</th>
                            <th>amount</th>
                            <th>option</th>
                        </tr>
                        <tr>
                            <td>jhon doe</td>
                            <td>st james collge</td>
                            <td>$120</td>
                            <td><a href="#"class="btn">view</a></td>
                        </tr>
                        <tr>
                            <th>name</th>
                            <th>school</th>
                            <th>amount</th>
                            <th>option</th>
                        </tr>
                        <tr>
                            <td>jhon doe</td>
                            <td>st james collge</td>
                            <td>$120</td>
                            <td><a href="#"class="btn">view</a></td>
                        </tr>
                        <tr>
                            <th>name</th>
                            <th>school</th>
                            <th>amount</th>
                            <th>option</th>
                        </tr>
                        <tr>
                            <td>jhon doe</td>
                            <td>st james collge</td>
                            <td>$120</td>
                            <td><a href="#"class="btn">view</a></td>
                        </tr>
                        <tr>
                            <th>name</th>
                            <th>school</th>
                            <th>amount</th>
                            <th>option</th>
                        </tr>
                        <tr>
                            <td>jhon doe</td>
                            <td>st james collge</td>
                            <td>$120</td>
                            <td><a href="#"class="btn">view</a></td>
                        </tr>
                    </table>
                </div>
                <div class="new-students">
                    <div class="title">
                        <h2>New students</h2>
                        <a href="#" class="btn">view all</a>
                </div>
                <table>
                    <tr>
                        <th>profile</th>
                        <th>name</th>
                        <th>opcion</th>
                    </tr>
                    <tr>
                        <td><img src="image/user.png" alt=""></td>
                        <td>jhon steve doe</td>
                        <td><img src="image/info.png" alt=""></td>
                    </tr>
                    <tr>
                        <td><img src="image/user.png" alt=""></td>
                        <td>jhon steve doe</td>
                        <td><img src="image/info.png" alt=""></td>
                    </tr>
                    <tr>
                        <td><img src="image/user.png" alt=""></td>
                        <td>jhon steve doe</td>
                        <td><img src="image/info.png" alt=""></td>
                    </tr>
                    <tr>
                        <td><img src="image/user.png" alt=""></td>
                        <td>jhon steve doe</td>
                        <td><img src="image/info.png" alt=""></td>
                    </tr>
            </table>
            </div>
        </div>
    </div>  
</html>