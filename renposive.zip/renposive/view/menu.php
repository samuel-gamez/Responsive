<div class="side-menu">
        <div class="brand-name">
            <h1>Brand</h1>
        </div>
        <ul>
            <li> <img src="image/dashboard (2).png" alt="">&nbsp;<span>Dashboard</span></li>
            <li> <img src="image/reading-book (1).png" alt="">&nbsp;<span>students</span> </li>
            <li> <img src="image/teacher2.png" alt="">&nbsp;<span>teacher</span> </li>
            <li> <img src="image/school.png" alt="">&nbsp;<span>school</span> </li>
            <li> <img src="image/payment.png" alt="">&nbsp;<span>income</span></li>
            <li> <img src="image/help-web-button.png" alt="">&nbsp;<span>help</span></li>
            <li> <img src="image/settings.png" alt="">&nbsp;<span>settings</span></li> 
        </ul>
    </div>